from domain.piece import create_piece
from domain.board import Board, MS_PER_CELL
from adapters.board_parser import parse_game_data, check_valid
from adapters.board_mapper import pixel_to_cell
from services.real_time_arbiter import RealTimeArbiter

import sys

def main():
    input_text = sys.stdin.read()   
    lines = input_text.splitlines()
    chess, commands = parse_game_data(lines)
    
    if not chess:
        return
        
    first_row_tokens = chess[0]
    length_cols = len(first_row_tokens)
    length_rows = len(chess)

    for i in range(length_rows):
        if len(chess[i]) != length_cols:
            print("ERROR", ERR_ROW_WIDTH_MISMATCH)
            return

    if check_valid(chess) == 0:
        return
        
    chess = Board(chess) 

    selected_piece = None
    arbiter = RealTimeArbiter()
    for line in commands:
        parts = line.split()
        if not parts:
            continue
        if not game_over:
            game_over=update_board_by_time(chess, current_time, pending_moves)
        cmd_type = parts[0]

        if cmd_type == "click" and not arbiter.game_over:
            x = int(parts[1])
            y = int(parts[2])
            row,col=pixel_to_cell(x,y)
            selected_piece = handle_click(chess, row, col, selected_piece, current_time, pending_moves)
            

        elif cmd_type == "print":
            print_board(chess, parts)

        elif cmd_type == "wait":
            wait_duration = int(parts[1])
            arbiter.current_time(wait_duration)
            arbiter.update_board_by_time(chess)
    

if __name__ == "__main__":
    main()