from domain.board import MS_PER_CELL

class RealTimeArbiter:
    def __init__(self):
        self.current_time = 0
        self.pending_moves = []
        self.game_over = False

    def advance_time(self, ms):
        self.current_time += ms

    def register_move(self, start, end, piece, distance):
        duration = distance * MS_PER_CELL
        arrival_time = self.current_time + duration
        self.pending_moves.append({
            'start': start,
            'end': end,
            'piece': piece,
            'arrival_time': arrival_time
        })
    

    def handle_click(self,chess,row,col,selected_piece):
        if row < 0 or row >= chess.rows or col < 0 or col >= chess.cols:
            return selected_piece
        
        for move in self.pending_moves:
            if move['start'] == (row, col):
                return selected_piece
        #במידה וזה האיבר הראשון שהשחקן לחץ
        if selected_piece is None:
            if not chess.is_empty(row,col):
                selected_piece = (row, col)
            return selected_piece
        else:
            prev_row, prev_col = selected_piece
            selected_piece_name = chess.get_piece_str(prev_row, prev_col)

        #אם התבצע לחיצה על איבר מאותו הצבע -נתיחס ללחיצה האחרונה
            if not chess.is_empty(row, col) and chess.get_piece_color(row, col) == selected_piece_name[0]:
                selected_piece = (row, col)
                return selected_piece
            else:
                piece = create_piece(selected_piece_name)
                #אם לפי הדרישות הכלי יכול לזוז למקום החדש
                if piece.can_move(chess.grid, (prev_row, prev_col), (row, col)):     

                    distance = max(abs(row - prev_row), abs(col - prev_col))
                    duration = distance * MS_PER_CELL
                    arrival_time = current_time + duration
                    #נוסיף איבר חדש למערך האיברים שבתזוזה
                    pending_moves.append({
                        'start': (prev_row, prev_col),
                        'end': (row, col),
                        'piece': selected_piece_name,
                        'arrival_time': arrival_time
                    })
                    #מנקים לפקודה חדשה של תזוזה
                    selected_piece = None
                return selected_piece



    def update_board_by_time(self, chess):
        if self.game_over:
            return
        moves_to_keep = []
        for move in self.pending_moves:
            if self.current_time >= move['arrival_time']:
                target = chess.get_piece_str(move['end'][0], move['end'][1])
                if target and target[1] == 'K':
                    self.game_over = True
                chess.set_piece(move['end'][0], move['end'][1], move['piece'])
                chess.clear_cell(move['start'][0], move['start'][1])
                piece_str = move['piece']
                end_row = move['end'][0]
                if piece_str[1] == 'P':
                    last_row = 0 if piece_str[0] == 'w' else len(chess.grid) - 1
                    if end_row == last_row:
                        chess.set_piece(end_row, move['end'][1], piece_str[0] + 'Q')
            else:
                moves_to_keep.append(move)
        self.pending_moves = moves_to_keep


    def is_moving(self, row, col):
        return any(move['start'] == (row, col) for move in self.pending_moves)


    
