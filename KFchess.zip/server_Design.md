
                              ┌─────────────────────┐
                              │   Client   │
                              └───────────┬───────────┘
                     ┌──────────────────────┴───────────────────────┐
                     ▼                                                ▼
          ┌─────────────────────┐                       ┌──────────────────────────┐
          │     API Gateway        │                       │        Matchmaker            │
          │ login / history / rooms│                       │  Stateless · Elo · ZSET      │
          └───────────┬───────────┘                       └────────────┬───────────────┘
                     ▼                                                 ▼
          ┌─────────────────────┐                       ┌──────────────────────────┐
          │      PostgreSQL         │                       │     Game Allocator  ★       │
          │  users · Elo · results  │                       │  geo latency + load balance  │
          └─────────────────────┘                       └────────────┬───────────────┘
                                                                       ▼
                                                     ┌───────────────────────────────┐
                                                     │      Game Server Shard (A)       │
                                                     │  Stateful · Tick 100ms           │
                                                     │  GameEngine = Source of Truth    │
                                                     └──────┬──────────┬──────────┬──────┘
                                                            │          │          │
                             WebSocket ישיר, בלי Gateway ──┘          │          │
                             (Yossi + Dani — אפס Latency)             ▼          ▼
                                                       ┌──────────────────┐  ┌───────────────────┐
                                                       │   Redis Cluster    │  │  Message Bus (NATS) ★│
                                                       │ room:*:stream      │  │ room:{id}:events     │
                                                       │ room:*:meta        │  │ room:{id}:score      │
                                                       │ owner+epoch(fencing│  │ room:{id}:state      │
                                                       └─────────┬────────┘  └──────────┬───────────┘
                                                                 ▼                        ▼
                                                     ┌──────────────────────┐  ┌────────────────────────┐
                                                     │ Session Recovery Svc   │  │ Spectator Edge Servers ★ │
                                                     │ fencing token→Shard B  │  │ fan-out לאלפי צופים        │
                                                     └──────────────────────┘  └────────────────────────┘

                              ┌───────────────────────────────────────────────┐
                              │        Observability ★ — logs · metrics · health   │
                              │   מזין את ה-Liveness Probes של כל הרכיבים למעלה      │
                              └───────────────────────────────────────────────┘
```

הסבר קצר על הרכיבים והקשר ביניהם:

API Gateway (HTTP רגיל) ו-Matchmaker (שידוך) הם שתי נקודות כניסה נפרדות מהרגע הראשון — כל אחת עם אחריות משלה.
Matchmaker (Stateless, Elo, ZSET) אחראי רק על "מי משחק עם מי"; Game Allocator ★ אחראי רק על "איפה זה ירוץ" (עומס/גיאוגרפיה) — פיצול אחריות שאומץ מהצעת הצוות.
Game Server Shard הוא ה-Source of Truth היחיד למשחק; השחקנים מתחברים אליו ישירות ב-WebSocket, בלי Gateway מתווך, כדי לשמור על אפס Latency בזמן אמת.
Redis Cluster משמש רק לגיבוי אסינכרוני (Stream+Hash) ולמנגנון ה-Fencing Token למניעת Split-Brain — לא לתקשורת החיה של המשחק.
Message Bus (NATS) ★ נפרד לגמרי מ-Redis, עם topics מופרדים לפי סוג צרכן (events/score/state) — כדי לא ליצור ערוץ-על שכולם נרשמים אליו ומסננים בעצמם.
Spectator Edge Servers ★ נרשמים ל-Bus ומפיצים לצופים — מבודדים לחלוטין מהעומס על ה-Shard, וניתנים ל-Scaling עצמאי לפי ביקוש צופים.
Observability ★ מנטר את כל הרכיבים ומזין את ה-Liveness Probes שה-Session Recovery Service תלוי בהם לזיהוי כשלים.